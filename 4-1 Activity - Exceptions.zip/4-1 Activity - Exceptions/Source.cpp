// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// CustomException class that extends from std::exception
struct CustomException : public std::exception
{
	virtual const char* what() const throw()
	{
		return "Test of standard exception message";
	}
};

bool do_even_more_custom_application_logic() {
	std::cout << "Running Even More Custom Application Logic." << std::endl;
	throw std::bad_exception();
	return true;
}

void do_custom_application_logic() {
	std::cout << "Running Custom Application Logic." << std::endl;

	try {
		if (do_even_more_custom_application_logic()) {
			std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
		}
	}
	catch (const std::exception& exception) {
		std::cerr << "Caught exception in do_custom_application_logic: " << exception.what() << std::endl;
	}

	throw CustomException();
	std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den) {
	if (den == 0) {
		throw std::runtime_error("Divide by zero error");
	}
	return num / den;
}


void do_division() noexcept {
	float numerator = 10.0f;
	float denominator = 0;

	try {
		auto result = divide(numerator, denominator);
		std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
	}
	catch (const std::exception& exception) {
		std::cerr << "Caught exception in do_division: " << exception.what() << std::endl;
	}
}


int main() {
	try {
		std::cout << "Exceptions Tests" << std::endl;

		do_division();
		do_custom_application_logic();
	}
	catch (const CustomException& exception) {
		std::cerr << "Caught CustomException in main: " << exception.what() << std::endl;
	}
	catch (const std::exception& exception) {
		std::cerr << "Caught std::exception in main: " << exception.what() << std::endl;
	}
	catch (...) {
		std::cerr << "Caught unknown exception in main." << std::endl;
	}

	return 0;
}
